public interface GameShower {
    int getSize();
    void show();
}
