
import java.awt.Color;
import java.util.List;

import biuoop.DrawSurface;
import java.util.ArrayList;
/**
* @author Aviv Shisman 206558157
*/
public class Block implements Collidable, Sprite, HitNotifier {
    //members:
    private Rectangle rect;
    private java.awt.Color color;
    private int life;
    private List<HitListener> hitListeners;

    /**the constructor creating a block.
     * @param rect the rectangle shape of block*/
    public Block(Rectangle rect) {
        this.hitListeners = new ArrayList<HitListener>();
        this.rect = rect;
        this.color = Color.BLACK;
        this.life = 1;
    }
    /**the constructor creating a block.
     * @param rect the rectangle shape of block
     * @param color the color of the block*/
    public Block(Rectangle rect, Color color) {
        this.hitListeners = new ArrayList<HitListener>();
        this.rect = rect;
        this.color = color;
        this.life = 1;
    }
    /**the constructor creating a block.
     * @param rect the rectangle shape of block
     * @param color the color of the block
     * @param life the life of the block*/
    public Block(Rectangle rect, Color color, int life) {
        this.hitListeners = new ArrayList<HitListener>();
        this.rect = rect;
        this.color = color;
        this.life = life;
    }
    /**get the shape of the block the rectangle.
     * @return the rectangle*/
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }
    /**after the ball hits a block givinig him a new velocity.
     * @param collisionP the collision point
     * @param currentV the current velocity
     * @param hitter the ball that hits
     * @return the new velocity*/
    public Velocity hit(Ball hitter, Point collisionP, Velocity currentV) {
        if (life > 0) {
            this.life--;
        }
        this.notifyHit(hitter);
        double dx = currentV.getDX();
        double dy = currentV.getDY();
        int flag = 0;
        if (Math.abs(collisionP.getY() - rect.getUpperLeft().getY()) < 0.0001
                || Math.abs(collisionP.getY()
                        - (rect.getUpperLeft().getY() + rect.getHeight())) < 0.0001) {
            dy = -currentV.getDY();
            flag++;
        }
        if (Math.abs(collisionP.getX() - rect.getUpperLeft().getX()) < 0.0001
                || Math.abs(collisionP.getX()
                        - (rect.getUpperLeft().getX() + rect.getWidth())) < 0.0001) {
            dx = -currentV.getDX();
            flag++;
        }
        if (flag == 2) {
            return new Velocity(-currentV.getDX(), -currentV.getDY());
        }

        return new Velocity(dx, dy);
    }
    /**the method for drawing a block.
    * @param surface the gui surface.*/
    public void drawOn(DrawSurface surface) {
        //drawing the rectangle
        surface.setColor(this.color);
        surface.fillRectangle((int) rect.getUpperLeft().getX()
                , (int) rect.getUpperLeft().getY(), (int) rect.getWidth(),
                (int) rect.getHeight());
        surface.setColor(Color.black);
        surface.drawRectangle((int) rect.getUpperLeft().getX()
                , (int) rect.getUpperLeft().getY(), (int) rect.getWidth(),
                (int) rect.getHeight());
    }
    /** calling timepassed method that does nothing in this case.*/
    public void timePassed() {

    }
    /**adding the block to the game.
     * @param g the game*/
    public void addToGame(GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }
    /** removing the block from the game.
     * @param gameLevel the game */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeCollidable(this);
        gameLevel.removeSprite(this);
    }
    /** adding hit listener.
     * @param hl the hit listener */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }
    /** removing hit listener.
     * @param hl the hit listener */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }
    /** getting the life of a block.
     * @return the life of the block*/
    public int getLife() {
        return this.life;
    }
    /** notify all the hit listeners on a hit.
     * @param hitter the ball*/
    private void notifyHit(Ball hitter) {
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }

}
