public interface Player {
    Point oneMove(Point[] pointsArr, int a);
    char getSymbol();
}
