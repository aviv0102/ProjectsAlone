public class Point {
    int x, y;
    Point(int a, int b) {
        x =a;
        y = b;
    }

    int getX() { return x; }

    int getY() { return y; }
}
