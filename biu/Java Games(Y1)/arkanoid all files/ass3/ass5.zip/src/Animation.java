
import biuoop.DrawSurface;
/**
* @author Aviv Shisman 206558157
*/
public interface Animation {
   /** drawing one frame on the screen.
   * @param d the drawsurface. */
   void doOneFrame(DrawSurface d);
   /** telling the animationrunner if he need to stop.
   * @return the result */
   boolean shouldStop();
}