import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
/**
* @author Aviv Shisman 206558157
*/
public class PauseScreen implements Animation {
    //memebers:
    private KeyboardSensor keyboard;
    private boolean stop;
    /**the constructor.
     * @param k the keyboard*/
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        this.stop = false;
    }
    /** drawing the pause screen.
     *@param d the draw surface*/
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.stop = true;
        }
    }
    /**telling the animation runner to stop.
     * @return to stop or not*/
    public boolean shouldStop() {
        return this.stop;
    }
}