
import java.util.List;
import biuoop.GUI;
import biuoop.KeyboardSensor;
/**
* @author Aviv Shisman 206558157
*/
public class GameFlow {
    //the members:
    private Counter points;
    private Counter lives;
    private GUI gui;
    private AnimationRunner ar;
    private KeyboardSensor ks;
    /** the constructor.
     * @param ar animation runner
     * @param ks keyboard sensor
     * @param gui the gui*/
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, GUI gui) {
        this.points = new Counter();
        this.lives = new Counter();
        lives.increase(7);
        this.ar = ar;
        this.ks = ks;
        this.gui = gui;
    }
    /**running the game levels.
     * @param levels the list of levels we run */
    public void runLevels(List<LevelInformation> levels) {

        for (LevelInformation levelInfo : levels) {
            GameLevel level = new GameLevel(levelInfo, this.ar, this.ks, this.gui, this.points, this.lives);
            level.initialize();
            while (this.lives.getValue() > 0 && level.getRemainBlocks().getValue() > 0) {
                level.playOneTurn();
            }
            if (this.lives.getValue() == 0) {
                break;
            }
        }
        this.ar.run(new EndScreen(this.ks, this.points, 1, gui));

    }

}
