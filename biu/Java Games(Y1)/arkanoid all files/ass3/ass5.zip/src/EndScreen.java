
import biuoop.GUI;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
* @author Aviv Shisman 206558157
*/
public class EndScreen implements Animation {
    //the members:
    private GUI gui;
    private KeyboardSensor keyboard;
    private boolean stop;
    private Counter score;
    private int result;
    /** the constructor.
     * @param k the KeyboardSensor
     * @param s the counter
     * @param result if the player won or not
     * @param g the gui */
    public EndScreen(KeyboardSensor k, Counter s, int result, GUI g) {
        this.keyboard = k;
        this.stop = false;
        this.score = s;
        this.result = result;
        this.gui = g;
    }
    /**running the end screen.
     * @param d the drawSurface*/
    public void doOneFrame(DrawSurface d) {
        if (result == 1) {
            d.drawText(20, d.getHeight() / 2,
                    "Thank you for playing!, Your score is:"
            + Integer.toString(score.getValue()), 40);
        }
        if (result == 0) {
            d.drawText(10, d.getHeight() / 2, "Game Over. Your score is :"
        + Integer.toString(score.getValue()), 32);
        }
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.gui.close();
        }
    }
    /** if the animation should stop stops it.
     * @return the answer */
    public boolean shouldStop() {
        return this.stop;
    }
}
